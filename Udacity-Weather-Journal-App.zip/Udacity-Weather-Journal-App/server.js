//setup empty JS object to act as endpoint for all routes
projectData = {};

//Require express to run server and routes

const express = require('express');


/* Dependencies */
const bodyParser = ('body-parser');


//Start up an instance of app
const app = express();

/* Middleware */
//Here we are configuring express to use body-parser as middle-ware.

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

//Initialise the main project folder
app.use(express.static('website'));

//Set up server
const port = 8000;
const server = app.listen(port, listening);

//Callback to debug
function listening() {
    console.log('server running');
    console.log('running on localhost: ${port}');
}

// Initializa all route with a callback get function

app.get('/allData', sendData);

function sendData(req, res) {
    res.send(projectData);
}
// Create an array to hold data     
const projectData = [];

//Post function

app.post('/addData', addData);

function addData(req, res) {

    console.log(req.body);
    newEntry = {
        date: req.body.date,
        temp: req.body.temp,
        content: req.body.content
    }

    projectData.push(newEntry);
    console.log(projectData)
}