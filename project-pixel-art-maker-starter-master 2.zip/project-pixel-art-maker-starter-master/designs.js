

// Select color input
// Select size input
var rows, columns, addColor;

// When size is submitted by the user, call makeGrid()
$(document).ready(function() {
  $('#sizePicker').submit(function makeGrid(grid) {
    $('table tr').remove();
    var rows = $('#inputHeight').val();
    var columns = $('#inputWidth').val();

    // Your code goes here!
       for(var i = 1; i <= rows; i++) {
         $('table').append('<tr></tr>');
         for(var j = 1; j <= columns; j++) {
           $('tr:last').append('<td></td>');
           $('td').attr("class", 'cells');
          }
        }
        grid.preventDefault();
        //adding color to the cells
        $('.cells').click(function(event) {
          var addColor = $('#colorPicker').val();
          $(event.target).css('background-color', addColor)
        });
     });
 });
