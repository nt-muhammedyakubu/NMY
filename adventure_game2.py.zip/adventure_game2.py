

import time
#  import time to pause
import random
#  import random to select game parameters

#  lists of game parameters
house_monsters = ['manticore', 'wicked fierie', 'dragon', 'troll']
cave_weapon = ['magical sword of ogoroth', 'dragon breath sword']


def print_pause(message_to_print, time_to_sleep):
    print(message_to_print)
    time.sleep(2)


def valid_choice_input(prompt, option1, option2):
    while True:
        response = input(prompt)
        if option1 in response:
            break
        elif option2 in response:
            break
        else:
            print_pause('Sorry, I don\'t understand', 2)
    return response


def intro():
    print_pause('Welcome to the adventure game.', 2)
    print_pause('You will be allowed to make choices during'
                ' the game that will make you victorious or'
                ' defeated but, you need to think very well'
                ' before making your choice.', 2)
    name = input('Please enter your name to start the game.\n')
    field()


def field():
    print_pause('You find youself standing in an open field,'
                ' filled with grasses and yellow wild flowers.', 2)
    print_pause('Rumour has it that a mysterious creature is'
                ' somewhere around here and has been'
                ' terrifying the nearby village.', 2)
    print_pause('In front of you is a house.', 2)
    print_pause('To your right is a dark cave.', 2)
    print_pause('In your hand, you hold an old'
                ' silly (but not very effective) dagger.', 2)
    print_pause('Enter 1 to knock on the door of the house.', 2)
    print_pause('Enter 2 to peer into the cave.', 2)
    response = valid_choice_input('Please enter 1 or 2.\n', '1', '2')
    if response == '1':
        house()
    elif response == '2':
        cave()


def house():
    monster = random.choice(house_monsters)
    print_pause('You approach the door of the house.', 2)
    print_pause('You are about to knock when the door open and'
                ' out steps a ' + monster, 2)
    print_pause('Eep! this is where the '
                + monster + ' lives ', 2)
    print_pause('The ' + monster + ' attacks you', 2)
    print_pause('You feel a bit underprepared for this'
                ' with only a small silly old dagger', 2)
    print_pause('Would you like to (a) fight or (b) runaway?', 2)
    response = valid_choice_input('Please enter a or b.\n', 'a', 'b')
    if response == 'a':
        fight()
    elif response == 'b':
        runaway()


def cave():
    print_pause('You peer cautiously into the cave.', 2)
    print_pause('It turns out to be only a small cave.', 2)
    print_pause('Your eye catches a glint of a metal behind a rock.', 2)
    print_pause('You have found the ' + random.choice(cave_weapon), 2)
    print_pause('You discard your old silly dagger and'
                ' takes the sword with you.', 2)
    print_pause('You walk back into the field.', 2)
    print_pause('What would you like to do?', 2)
    print_pause('Enter 1 to knock on the door.', 2)
    print_pause('Enter 2 to peer into the cave.', 2)
    response = valid_choice_input('Please enter 1 or 2.\n', '1', '2')
    if response == '2':
        cave_again()
    elif response == '1':
        house()


def cave_again():
    print_pause('You peer cautiously into the cave.', 2)
    print_pause('You\'ve been here before, and gotten all'
                ' the good stuff. It\'s just an empty cave now.', 2)
    print_pause('You walk back into the field.', 2)
    print_pause('What would you like to do?', 2)
    print_pause('Would you like to play again?', 2)
    response = valid_choice_input('Please enter y or n.\n', 'y', 'n')
    if response == 'y':
        restarting_the_game()
    elif response == 'n':
        print_pause('Game over! Thanks for playing! See you next time.', 2)


def fight():
    monster = random.choice(house_monsters)
    print_pause('As the ' + monster +
                ' moves to attack, you unshealth your new sword.', 2)
    print_pause('The ' + random.choice(cave_weapon) + ' shines brightly'
                ' in your hand as you brace youself for the attack.', 2)
    print_pause('But the ' + monster + ' takes one look'
                ' at your new shiny toy and runs away.', 2)
    print_pause('You have rid the village of the '
                + monster, 2)
    print_pause('You are victorious!', 2)
    print_pause('Would you like to play again.', 2)
    response = valid_choice_input('Please enter y or n.\n', 'y', 'n')
    if response == 'y':
        restarting_the_game()
    elif response == 'n':
        print_pause('Game over! Thanks for playing. See you next time.', 2)


def runaway():
    monster = random.choice(house_monsters)
    print_pause('You do your best for your dagger is no match'
                ' for the ' + monster, 2)
    print_pause('You are defeated!', 2)
    print_pause('What would you like to do?', 2)
    print_pause('Would you like to play again?', 2)
    response = valid_choice_input('Please enter y or n.\n', 'y', 'n')
    if response == 'y':
        restarting_the_game()
    elif response == 'n':
        print_pause('Game over! Thanks for playing. See you next time.', 2)


def restarting_the_game():
    print_pause('Excellent! Restarting the game.', 2)
    play_adventure_game()


def play_adventure_game():
    intro()


play_adventure_game()
